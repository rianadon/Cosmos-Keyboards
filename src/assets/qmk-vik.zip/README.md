This folder contains what's in [sadekbaroudi/qmk_firmware@develop_fingerpunch:keyboards/fingerpunch/src/vik](https://github.com/sadekbaroudi/qmk_firmware/tree/develop_fingerpunch/keyboards/fingerpunch/src/vik). This is my attempt at making the VIK resources portable.

For more resources on these VIK libraries:
- https://github.com/sadekbaroudi/qmk_firmware/blob/develop_fingerpunch/keyboards/fingerpunch/FP_LIBRARY_SUPPORT.md
- https://github.com/sadekbaroudi/qmk_firmware/blob/develop_fingerpunch/keyboards/fingerpunch/README.md
